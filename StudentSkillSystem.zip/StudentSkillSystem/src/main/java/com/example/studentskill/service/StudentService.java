package com.example.studentskill.service;

import com.example.studentskill.model.Student;
import com.example.studentskill.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    // Requirement 8: Prevent duplicate student IDs and validate scores between 0 and 100
    public Student addStudent(Student student) {
        if (student.getStudentId() == null || repository.existsById(student.getStudentId())) {
            throw new IllegalArgumentException("Duplicate or null Student ID: " + student.getStudentId());
        }
        validateScores(student.getProgrammingScore(), student.getMathematicsScore());
        return repository.save(student);
    }

    public void validateScores(double progScore, double mathScore) {
        if (progScore < 0 || progScore > 100 || mathScore < 0 || mathScore > 100) {
            throw new IllegalArgumentException("Scores must be between 0 and 100.");
        }
    }

    // Requirement 1: Calculate each student's average score
    public double calculateAverage(Student student) {
        return (student.getProgrammingScore() + student.getMathematicsScore()) / 2.0;
    }

    // Requirement 2: Assign performance category based on average
    public String getPerformanceCategory(double average) {
        if (average >= 85.0) {
            return "Excellent";
        } else if (average >= 70.0) {
            return "Good";
        } else if (average >= 50.0) {
            return "Satisfactory";
        } else {
            return "Needs Improvement";
        }
    }

    // Requirement 3: Identify the stronger subject for each student
    public String getStrongerSubject(Student student) {
        if (student.getProgrammingScore() > student.getMathematicsScore()) {
            return "Programming";
        } else if (student.getMathematicsScore() > student.getProgrammingScore()) {
            return "Mathematics";
        } else {
            return "Equal in Both";
        }
    }

    // Helper method combining student profile with Requirements 1, 2, and 3
    public Map<String, Object> getStudentSummary(Student student) {
        double average = calculateAverage(student);
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("student", student);
        summary.put("averageScore", average);
        summary.put("performanceCategory", getPerformanceCategory(average));
        summary.put("strongerSubject", getStrongerSubject(student));
        return summary;
    }

    // Requirement 4: Search for students by ID, email, or course
    public Student searchById(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Student not found with ID: " + id));
    }

    public Student searchByEmail(String email) {
        return repository.findByEmailAddressIgnoreCase(email)
                .orElseThrow(() -> new NoSuchElementException("Student not found with email: " + email));
    }

    public List<Student> searchByCourse(String course) {
        return repository.findByCourseNameIgnoreCase(course);
    }

    // Requirement 5: Generate a merit list sorted by average score in descending order
    @SuppressWarnings("rawtypes")
    public List generateMeritList() {
        return repository.findAll().stream()
                .sorted(Comparator.comparingDouble(this::calculateAverage).reversed())
                .map(this::getStudentSummary)
                .collect(Collectors.toList());
    }

    // Requirement 6: Identify students who have the same technical skills
    public Map<Set<String>, List<String>> findStudentsWithSameSkills() {
        Map<Set<String>, List<String>> skillMap = new HashMap<>();

        for (Student s : repository.findAll()) {
            Set<String> normalizedSkills = s.getTechnicalSkills().stream()
                    .map(skill -> skill.trim().toLowerCase())
                    .collect(Collectors.toSet());

            skillMap.computeIfAbsent(normalizedSkills, k -> new ArrayList<>())
                    .add(s.getStudentName() + " (ID: " + s.getStudentId() + ")");
        }

        return skillMap.entrySet().stream()
                .filter(entry -> entry.getValue().size() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    // Requirement 7: Display students who need improvement in programming (< 50)
    // but have a mathematics score of at least 75
    public List<Student> findLowProgHighMathStudents() {
        return repository.findAll().stream()
                .filter(s -> s.getProgrammingScore() < 50.0 && s.getMathematicsScore() >= 75.0)
                .collect(Collectors.toList());
    }

    // Additional CRUD methods needed for Q3 REST APIs
    @SuppressWarnings("rawtypes")
    public List getAllStudents() {
        return repository.findAll().stream()
                .map(this::getStudentSummary)
                .collect(Collectors.toList());
    }

    public Student updateScoresAndSkills(Integer id, double progScore, double mathScore, List<String> newSkills) {
        Student existing = searchById(id);
        validateScores(progScore, mathScore);
        existing.setProgrammingScore(progScore);
        existing.setMathematicsScore(mathScore);
        if (newSkills != null) {
            existing.setTechnicalSkills(newSkills);
        }
        return repository.save(existing);
    }

    public void deleteStudent(Integer id) {
        if (!repository.existsById(id)) {
            throw new NoSuchElementException("Student not found with ID: " + id);
        }
        repository.deleteById(id);
    }
}