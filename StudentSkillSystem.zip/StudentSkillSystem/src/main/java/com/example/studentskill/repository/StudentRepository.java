package com.example.studentskill.repository;

import com.example.studentskill.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
    // Supports Requirement 4: Search by email or course
    Optional<Student> findByEmailAddressIgnoreCase(String emailAddress);
    List<Student> findByCourseNameIgnoreCase(String courseName);
}