package com.example.studentskill.controller;

import com.example.studentskill.model.Student;
import com.example.studentskill.service.StudentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    // 1. Add a student (POST /api/students)
    @PostMapping
    public ResponseEntity<?> addStudent(@RequestBody Student student) {
        try {
            Student saved = service.addStudent(student);
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // 2. Retrieve all students (GET /api/students)
    @GetMapping
    @SuppressWarnings("rawtypes")
    public ResponseEntity<List> getAllStudents() {
        return ResponseEntity.ok(service.getAllStudents());
    }

    // 3. Search for a student by ID (GET /api/students/{id})
    @GetMapping("/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable Integer id) {
        try {
            Student student = service.searchById(id);
            return ResponseEntity.ok(service.getStudentSummary(student));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        }
    }

    // Search by Email & Course (Q2.4)
    @GetMapping("/search/email")
    public ResponseEntity<?> getByEmail(@RequestParam String email) {
        try {
            return ResponseEntity.ok(service.searchByEmail(email));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/search/course/{course}")
    public ResponseEntity<List<Student>> getByCourse(@PathVariable String course) {
        return ResponseEntity.ok(service.searchByCourse(course));
    }

    // 4. Update student scores and skills (PUT /api/students/{id})
    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Integer id, @RequestBody Student updatedData) {
        try {
            Student updated = service.updateScoresAndSkills(
                    id,
                    updatedData.getProgrammingScore(),
                    updatedData.getMathematicsScore(),
                    updatedData.getTechnicalSkills()
            );
            return ResponseEntity.ok(updated);
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // 5. Delete a student record (DELETE /api/students/{id})
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable Integer id) {
        try {
            service.deleteStudent(id);
            return ResponseEntity.ok(Map.of("message", "Student deleted successfully with ID: " + id));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        }
    }

    // 6. Display the merit list (GET /api/students/merit-list)
    @GetMapping("/merit-list")
    @SuppressWarnings("rawtypes")
    public ResponseEntity<List> getMeritList() {
        return ResponseEntity.ok(service.generateMeritList());
    }

    // Extra Q2 Analytics Endpoints
    @GetMapping("/same-skills")
    public ResponseEntity<?> getStudentsWithSameSkills() {
        return ResponseEntity.ok(service.findStudentsWithSameSkills());
    }

    @GetMapping("/low-prog-high-math")
    public ResponseEntity<List<Student>> getLowProgHighMath() {
        return ResponseEntity.ok(service.findLowProgHighMathStudents());
    }
}