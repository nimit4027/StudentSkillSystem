package com.example.studentskill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSkillSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
